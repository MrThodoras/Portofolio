#Date Created - 1/2/2026 11:13 PM - By Riris!

import math

def check(inp1,inp2,L1,L2):
    valid=True
    inp1=inp1.lower()
    inp2=inp2.lower()

    for i in range (len(inp1)):
        for j in range (len(L1)):
            if inp1[i] == L1[j]:
                valid=False
        for k in range (len(L2)):
            if inp1[i] == L2[k]:
                valid=False
    
    if inp2 != "`":
        for i in range (len(inp2)):
            for j in range (len(L1)):
                if inp2[i] == L1[j]:
                  valid=False
            for k in range (len(L2)):
                if inp2[i] == L2[k]:
                  valid=False

    return valid

def add (x,y):
    res=x+y
    return res 

def afairesh(x,y):
    res=x-y
    return res 

def pollmos(x,y):
    res=x*y
    return res 

def diairesh (x,y):
    float(x)
    res=x/y
    return res 

def power (x,v):
    res=x**v
    return res

def squirt (x):
   res=math.sqrt(x)
   return res


EnABC=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
GrABC=["α","β","γ","δ","ε","ζ","η","θ","ι","κ","λ","μ","ν","ξ","ο","π","ρ","σ","τ","υ","φ","χ","ψ","ω"]

Egk=["1","2","3","4","5","6","1312"]

# Arxiko print
cont=True
while cont==True:
    print ("Kalwsorises sto kompiouteraki tou riri! Lege twra ti thes na kaneis:")
    print ("1. Prosthesh") ; print("---------------------")
    print ("2. Afairesh ")
    print ("3. Pollaplasiasmos")
    print ("4. Diairesh")
    print ("5. Tetragwniki riza")
    print ("6. Dynamh")
    print ()

# Praksi Input
    praksi=input("Ti thes na kaneis? (Dialekse apo 1-6): ")

    while praksi not in Egk:
        praksi=input("Eipame dialekse apo 1-6: ") 
#If riza selected
    if praksi == "5" :
        arrizas=input("Dwse ton arithmo pou thes thn riza tou: ")
        
        valid=check(arrizas,"`",EnABC,GrABC)

        while not(valid):
            arrizas=input("Dwse ton ARITHMO pou thes thn riza tou VLAKA!: ")
            valid=check(arrizas,"`",EnABC,GrABC)

        arrizas=int(arrizas)
#If Dynamh selected
    if praksi == "6" :
        yps=input("Dwse ton arithmo pou thes na ypsoseis: ")
        sthn=input("Poso thes na ton ypsoseis: ")

        valid=check(yps,sthn,EnABC,GrABC)
        while not(valid):
            yps=input("Dwse ton ARITHMO pou thes na ypsoseis VLAKA!: ")
            sthn=input("Poso thes na ton ypsoseis? : ")
            valid=check(yps,sthn,EnABC,GrABC)

        yps=float(yps)
        sthn=float(sthn)
# File wriring
    if praksi == "1312":
        print ("Kalwsorises sto Arxeio tou riri!") 
        
        print ("Ti thes na kaneis?")
        print ("1. Na grapseis")
        print ("2. Na deis to periexomeno tou")

        arxthelei=input("")
        while arxthelei != "1" and arxthelei != "2":
            arxthelei=input("")
        
        if arxthelei == "1":
            f1=open("Calc.txt","a")

            print ("Dwse - (Pavla) gia na stamatiseis!")

            towr=input("Ti thes na grapseis? ")
            while towr != "-":
                f1.write(towr + "\n")
                towr=input("Ti thes na grapseis? ")
                f1.close()
        elif arxthelei == "2":
            f1=open("Calc.txt","r")
            print ()
            print("--------------START--------------")
            for line in f1:
                print (line)
            f1.close()
            print("---------------END---------------")

# Basic praksies input
    if praksi != "5" and praksi != "1312" and praksi != "6":
        ar1=input("Dwse ton prwto arithmo: ")
        ar2=input ("Dwse ton deutero arithmo: ")
        
        valid=check(ar1,ar2,EnABC,GrABC)

        while not(valid):
            ar1=input("Dwse ton prwto ARITMO vlaka!: ")
            ar2=input ("Dwse ton deutero ARITMO vlaka!: ")
            valid=check(ar1,ar2,EnABC,GrABC)

        ar1=float(ar1)
        ar2=float(ar2)

# Ypologismos

    if praksi=="1":
        apot=add (ar1,ar2)
    
    elif praksi=="2":
        apot=afairesh (ar1,ar2)

    elif praksi=="3":
        apot=pollmos (ar1,ar2)

    elif praksi=="4":
        apot=diairesh (ar1,ar2)
    
    elif praksi=="5":
        apot=squirt (arrizas)

    elif praksi=="6":
        apot=pow (yps,sthn)
   
    if praksi !="1312":
        print ()
        print ("To Apotelesma einai:", apot)


#Continue?
    print ()
    print ("Thes na kaneis allh praksh? y/n")

    con=input ("")
    con=con.lower()

    while con != "y" and con != "n":
        con=input ("Eipame y/n: ")

    if con == "n":
        cont=False    